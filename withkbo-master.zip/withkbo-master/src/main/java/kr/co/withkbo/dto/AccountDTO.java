package kr.co.withkbo.dto;

public class AccountDTO {

}
